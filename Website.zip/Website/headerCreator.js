document.write('\
<div class="head_container">\
      <div class="head_gradient">\
      </div>\
      <div class="head_block">\
        <a href="index.html">\
          <div class="logo_button">\
            <img src="logo.png"></img>\
          </div>\
        </a>\
        <a href="index.html">\
          <div class="head_button">\
            <h2>Home</h2>\
          </div>\
        </a>\
        <a href="index.html">\
          <div class="head_button">\
            <h2>Gospel</h2>\
          </div>\
        </a>\
        <a href="index.html">\
          <div class="head_button">\
            <h2>Rituals</h2>\
          </div>\
        </a>\
        <a href="index.html">\
          <div class="head_button">\
            <h2>Contact</h2>\
          </div>\
        </a>\
      </div>\
    </div>\
');